<?php
    require_once('extract/ExtractNewUsers.php');
    require_once('extract/ExtractUserUpdates.php');
    require_once('extract/ExtractBannedUsers.php');
    require_once('extract/UserRepository.php');
    require_once('transform/VbToRcTransform.php');
    require_once('load/RCLoader.php');

    $userRepo = new UserRepository();
    $source = new ExtractNewUsers($userRepo);
    $transf = new VbToRcTransform();
    $loader = new RCLoader();
    
    $dataBatch = $loader->loadMissingUsers($userRepo);
    $usersToImport = $transf->transform($dataBatch);
    
    echo "Count: " . count($usersToImport) . "\n";
    $loader->load($usersToImport);
?>