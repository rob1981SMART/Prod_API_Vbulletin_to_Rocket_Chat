<?php
    require_once('extract/ExtractNewUsers.php');
    require_once('extract/ExtractUserUpdates.php');
    require_once('extract/ExtractBannedUsers.php');
    require_once('extract/UserRepository.php');
    require_once('transform/VbToRcTransform.php');
    require_once('load/RCLoader.php');

    $userRepo = new UserRepository();
    $source = new ExtractNewUsers($userRepo);
    $transf = new VbToRcTransform();
    $loader = new RCLoader();

    $dataBatch = null;
    do {
        $dataBatch = $source->Extract();
        $usersToImport = $transf->transform($dataBatch);
        $loader->load($usersToImport);
    } while ($dataBatch != null);
    
    $source = new ExtractUserUpdates($userRepo);
    $transf = new VbToRcUpdateTransform();
    $dataBatch = $source->Extract();
    $usersToImport = $transf->transform($dataBatch);
    $loader->update($usersToImport);
    
    $source = new ExtractBannedUsers($userRepo);
    $transf = new VbToRcBannedTransform();
    $dataBatch = $source->Extract();
    $usersToImport = $transf->transform($dataBatch);
    $loader->ban($usersToImport);
    
    $loader->updateBannedUsers($userRepo);
?>