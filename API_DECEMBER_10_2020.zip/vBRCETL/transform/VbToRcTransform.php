<?php
    require_once('./interfaces/ITransform.php');
    class RcUserEntityDTO {
        public $username;
        public $name;
        public $email;
        public $password;
        public $fieldname;
        public $newvalue;

        public function createUserDTO($userid, $username, $email, $password) {
            $this->username = $username;
            $this->name = $userid;
            $this->email = $email;
            $this->password = $password;
        }
        
        public function updateUserDTO($username, $fieldname, $newvalue) {
            $this->username = $username;
            $this->fieldname = $fieldname;
            $this->newvalue = $newvalue;
        }
        
        public function bannedUserDTO($username) {
            $this->username = $username;
        }
    }
    
    class VbToRcTransform implements ITransform {
        public function transform($source) {
            if ($source) {
                $data = array();
                foreach($source as $userData) {
                    $newUser = new RcUserEntityDTO();
                    $newUser->createUserDTO($userData['userid'], 
                        $userData['username'], 
                        $userData['email'],
                        $this->rand_string());
                    array_push($data, $newUser);
                }
                
                return $data;
            }
        }

        private function rand_string($length = 8) {
            $chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
            return substr(str_shuffle($chars), 0, $length);
        }        
    }
    
    class VbToRcUpdateTransform implements ITransform {
        public function transform($source) {
            if ($source) {
                $data = array();
                foreach($source as $userData) {
                    $userUpdate = new RcUserEntityDTO();
                    $username = $userData['fieldname'] == 'username' ? $userData['oldvalue'] : $userData['username'];
                    $userUpdate->updateUserDTO($username,
                        $userData['fieldname'],
                        $userData['newvalue']);
                    array_push($data, $userUpdate);
                }
                
                return $data;
            }
        }
    }
    
    class VbToRcBannedTransform implements ITransform {
        public function transform($source) {
            if ($source) {
                $data = array();
                foreach($source as $userData) {
                    $userUpdate = new RcUserEntityDTO();
                    $userUpdate->bannedUserDTO($userData['username']);
                    array_push($data, $userUpdate);
                }
                
                return $data;
            }
        }
    }
?>