<?php
    require_once('./interfaces/ISource.php');
    require_once('./extract/MySQLSourceData.php');

    class ExtractUserUpdates extends MySQLSourceData implements ISource {
        public function Extract() {
            try {
                $users = $this->repository->getUserUpdates($this->getOffset('userUpdate'));
                if ($users){
                    $this->saveOffset('userUpdate', $this->repository->getOffset());
                }
                return $users;
            } catch (Exception $e){
                error_log("Unexpected error: ", $e->getMessage());
            }
        }
    }
?>