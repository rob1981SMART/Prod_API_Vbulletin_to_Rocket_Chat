<?php    

    abstract class MySQLSourceData {
        protected $repository;
        private $offsets;
        
        public function __construct(UserRepository $repository) {
            $this->repository = $repository;
            $this->offsets = array(
                "newUser" => 0,
                "userUpdate" => 0, 
                "banned" => 0);
            $this->getOffset('newUser');
            $this->getOffset('userUpdate');
            $this->getOffset('banned');
        }

        protected function getOffset($offsetName) {
            if (file_exists('offset.cnf')) {
                $offset = file_get_contents('offset.cnf');
                $result = json_decode($offset, true);
                $this->offsets["$offsetName"] = $result[$offsetName];
                return $this->offsets["$offsetName"];
            }
            else {
                return $this->offsets["$offsetName"];
            }
        }
        
        protected function saveOffset($offsetName, $offset) {
            $this->offsets["$offsetName"] = $offset;
            $data = json_encode($this->offsets);
            $file = fopen('offset.cnf', 'w');
            fwrite($file, $data);
            fclose($file);
        }
    }
?>