<?php
    require_once('config.php');
    class UserRepository {
        private $BATCH_SIZE = 10000;
        private $offset;

        public function getNewUsers($offset) {
            // start db connection.
            $data = array();
            $connection = new mysqli(DbConfig::$Host, DbConfig::$User, DbConfig::$Password, DbConfig::$DbName);

            if ($connection->connect_error) {
                error_log("Error when connecting to the DB.", 3, "error_log.log");
                exit;
            }

            $result = $connection->query($this->getNewUserQuery($offset));
            for ($i = 0; $i < $result->num_rows; $i++) {
                $row = $result->fetch_assoc();
                array_push($data, $row);
                $this->offset = $row["lastpost"];
            }

            $connection->close();
            return count($data) > 0 ? $data : null;
        }
        
        public function getInitialLoad($offset) {
            $data = array();
            $connection = new mysqli(DbConfig::$Host, DbConfig::$User, DbConfig::$Password, DbConfig::$DbName);

            if ($connection->connect_error) {
                error_log("Error when connecting to the DB.", 3, "error_log.log");
                exit;
            }

            $result = $connection->query($this->getInitialLoadQuery($offset));

            for ($i = 0; $i < $result->num_rows; $i++) {
                $row = $result->fetch_assoc();
                array_push($data, $row);
                $this->offset = $row["userid"];
            }

            $connection->close();
            return count($data) > 0 ? $data : null;
        }
        
        public function getUserUpdates($offset) {
            $data = array();
            $connection = new mysqli(DbConfig::$Host, DbConfig::$User, DbConfig::$Password, DbConfig::$DbName);

            if ($connection->connect_error) {
                error_log("Error when connecting to the DB.", 3, "error_log.log");
                exit;
            }

            $result = $connection->query($this->getUserUpdatesQuery($offset));

            for ($i = 0; $i < $result->num_rows; $i++) {
                $row = $result->fetch_assoc();
                array_push($data, $row);
                $this->offset = $row["changeid"];
            }

            $connection->close();
            return count($data) > 0 ? $data : null;
        }
        
        public function getBannedUsers($offset) {
            $data = array();
            $connection = new mysqli(DbConfig::$Host, DbConfig::$User, DbConfig::$Password, DbConfig::$DbName);

            if ($connection->connect_error) {
                error_log("Error when connecting to the DB.", 3, "error_log.log");
                exit;
            }

            $result = $connection->query($this->getBannedUserQuery($offset));

            for ($i = 0; $i < $result->num_rows; $i++) {
                $row = $result->fetch_assoc();
                array_push($data, $row);
            }

            $connection->close();
            $this->offset = strtotime("now");
            return count($data) > 0 ? $data : null;
        }
        
        public function getOffset() {
            return $this->offset;
        }
        
        public function isBannedUser($username) {
            $data = array();
            $connection = new mysqli(DbConfig::$Host, DbConfig::$User, DbConfig::$Password, DbConfig::$DbName);

            if ($connection->connect_error) {
                error_log("Error when connecting to the DB.", 3, "error_log.log");
                exit;
            }

            $result = $connection->query($this->isBannedUserQuery($username));
            
            for ($i = 0; $i < $result->num_rows; $i++) {
                $row = $result->fetch_assoc();
                array_push($data, $row);
            }

            $connection->close();
            return $result->num_rows > 0 ? $data : null;
        }
        
        public function getMissingUsers($userArray) {
            // start db connection.
            $data = array();
            $connection = new mysqli(DbConfig::$Host, DbConfig::$User, DbConfig::$Password, DbConfig::$DbName);

            if ($connection->connect_error) {
                error_log("Error when connecting to the DB.", 3, "error_log.log");
                exit;
            }

            $result = $connection->query($this->getMissingUserQuery(implode("','", $userArray)));

            for ($i = 0; $i < $result->num_rows; $i++) {
                $row = $result->fetch_assoc();
                array_push($data, $row);
                $this->offset = $row["userid"];
            }

            $connection->close();
            return count($data) > 0 ? $data : null;
        }
        
        private function getMissingUserQuery($userArray){
            return "SELECT u.userid, u.username, u.email, MAX(lastactivity) FROM vb_user u
            LEFT JOIN vb_userban ub ON ub.userid = u.userid
            WHERE u.username NOT IN ('$userArray')
            AND u.userid < 273897
            AND u.posts > 0
            AND ub.userid IS NULL
            AND u.usergroupid <> 8
            GROUP BY u.username, u.email";
        }

        private function getInitialLoadQuery($offset) {
            return "SELECT u.userid, u.username, u.email, MAX(lastactivity) FROM vb_user u
            LEFT JOIN vb_userban ub ON ub.userid = u.userid
            WHERE u.userid > $offset 
            AND u.posts > 0
            AND ub.userid IS NULL
            AND u.usergroupid <> 8
            GROUP BY u.username, u.email
            ORDER BY u.userid ASC
            LIMIT $this->BATCH_SIZE";
        }
        
        private function getNewUserQuery($offset) {
            return "SELECT u.userid, u.username, u.email, MAX(lastactivity), 
            u.lastpost FROM vb_user u
            WHERE u.lastpost > $offset 
            AND u.posts = 1
            GROUP BY u.username, u.email
            ORDER BY u.lastpost ASC
            LIMIT $this->BATCH_SIZE";
        }
        
        private function getUserUpdatesQuery($offset) {
            return "SELECT username, fieldname, newvalue, oldvalue, changeid FROM 
            (SELECT uc.userid, uc.changeid, uc.fieldname, uc.newvalue, u.username, uc.oldvalue
                FROM vb_userchangelog uc 
                LEFT JOIN vb_user u ON u.userid = uc.userid
                WHERE (fieldname = 'username' 
                    OR fieldname = 'email')
                ORDER BY changeid DESC) as changes
            WHERE changeid > $offset
            GROUP BY userid, fieldname";
        }
        
        private function getBannedUserQuery($offset) {
            return "SELECT u.username
            FROM vb_userban ub
            LEFT JOIN vb_user u ON u.userid = ub.userid
            WHERE bandate > '$offset'";
        }
        
        private function isBannedUserQuery($username) {
            return "SELECT ub.userid 
            FROM vb_userban ub
            LEFT JOIN vb_user u ON u.userid = ub.userid
            WHERE u.username = '$username'";
        }
    }
?>