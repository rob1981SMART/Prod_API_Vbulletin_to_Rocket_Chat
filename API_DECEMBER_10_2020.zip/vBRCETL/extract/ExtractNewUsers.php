<?php
    require_once('./interfaces/ISource.php');
    require_once('./extract/MySQLSourceData.php');

    class ExtractNewUsers extends MySQLSourceData implements ISource {
        public function Extract() {
            try {
                $newUsers = $this->repository->getNewUsers($this->getOffset('newUser'));
                if($newUsers) {
                    $this->saveOffset('newUser', $this->repository->getOffset());
                }
                return $newUsers;
            } catch (Exception $e){
                error_log("Unexpected error: ", $e->getMessage());
            }
        }
    }
?>