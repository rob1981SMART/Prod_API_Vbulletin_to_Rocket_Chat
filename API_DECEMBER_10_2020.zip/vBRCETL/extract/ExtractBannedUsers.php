<?php
    require_once('./interfaces/ISource.php');
    require_once('./extract/MySQLSourceData.php');

    class ExtractBannedUsers extends MySQLSourceData implements ISource {
        public function Extract() {
            try {
                $bannedUsers = $this->repository->getBannedUsers($this->getOffset('banned'));
                if($bannedUsers) {
                    $this->saveOffset('banned', $this->repository->getOffset());
                }
                return $bannedUsers;
            } catch (Exception $e){
                error_log("Unexpected error: ", $e->getMessage());
            }
        }
    }
?>