<?php 
    interface ISource {
        public function Extract();
    }
?>