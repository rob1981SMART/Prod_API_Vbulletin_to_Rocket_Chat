<?php 
    interface ILoad {
        public function load($users);
    }
?>