<?php 
    interface ITransform {
        public function transform($source);
    }
?>