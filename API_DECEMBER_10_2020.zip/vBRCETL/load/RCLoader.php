<?php
    require_once('./interfaces/ILoad.php');
    define("RC_USR", "");
    define("RC_PASS", "");

    class RCLoader implements ILoad {
        private $baseURL = 'https://chat.smartrecovery.community/';
        private $userid;
        private $token;
        private $cnt;
        
        public function __construct(){
            $this->setCredentials();
        }

        public function load($users) {
            $this->cnt = 0;
            if ($users) {
                foreach($users as $user) {
                    $this->createUser($user->name, $user->username, $user->email, $user->password);
                    sleep(0.5);
                }
            }
            echo "Total Users Exported = $this->cnt";
        }
        
        public function update($users) {
            $this->cnt = 0;
            if($users) {
                foreach($users as $user) {
                    $this->updateUser($user->username, $user->fieldname, $user->newvalue);
                    sleep(0.5);
                }
            }
        }
        
        public function ban($users) {
            if($users) {
                foreach($users as $user) {
                    $this->changeActiveStatus($user->username, false);
                    sleep(0.5);
                }
            }
        }
        
        public function updateBannedUsers($userRepo) {
            if (!$this->token)
                $this->authenticate();
            
            // Get banned users in Rocket chat.
            $path = 'api/v1/users.list?query=';
            
            $curl = curl_init();
            $queryParams = curl_escape($curl, '{"active": false, "_updatedAt":{"$gt":{"$date": "' . strtotime("-20 days") . '"}}}');
            
            $fieldParams = curl_escape($curl, '{ "username": 1}');
            curl_setopt_array($curl, $this->requestOpts("$path$queryParams&fields=$fieldParams", 'GET', null, $this->getAuthenticationHeaders()));
            $response = curl_exec($curl);
            curl_close($curl);
            
            $result = json_decode($response);
            if($result->users){
                foreach ($result->users as $user) {
                    if ($userRepo->isBannedUser($user->username) == null) {
                        $this->changeActiveStatus($user->username, true);
                        sleep(0.5);
                    }
                }
            }
        }
        
        public function loadMissingUsers($userRepo) {
            $userArray = array();
            $count = 65000;
            
            if (!$this->token)
                $this->authenticate();
            
            for ($i = 0; $i < 2; $i++) {
                // Get banned users in Rocket chat.
                
                $path = 'api/v1/users.list?count=' . $count . '&query=';
                $sortOrder = $i == 0 ? 1 : -1;
                
                $curl = curl_init();
                $queryParams = curl_escape($curl, '{"active": true, "_updatedAt":{"$gt":{"$date": "' . strtotime("-2 days") . '"}}}');
                
                $fieldParams = curl_escape($curl, '{ "username": 1}');
                $sortParams = curl_escape($curl, '{"username": ' . $sortOrder . '}');
                
                curl_setopt_array($curl, $this->requestOpts("$path$queryParams&fields=$fieldParams&sort=$sortParams", 'GET', null, $this->getAuthenticationHeaders()));
                $response = curl_exec($curl);
                curl_close($curl);
                
                $result = json_decode($response);
                if($result->users){
                    foreach ($result->users as $user) {
                        array_push($userArray, $user->username);
                    }
                }
            }
                
            return $userRepo->getMissingUsers($userArray);
        }

        private function authenticate() {
            $path = 'api/v1/login';
            $user = array(
                'user' => RC_USR,
                'password' => RC_PASS
            );

            $opts = $this->requestOpts($path, 'POST', json_encode($user), array("Content-Type: application/json"));

            $curl = curl_init();
            curl_setopt_array($curl, $opts);
            $response = curl_exec($curl);
            curl_close($curl);
            
            $result = json_decode($response, true);
            
            $this->token = $result['data']['authToken'];
            $this->userId = $result['data']['userId'];
            $this->saveCredentials();
        }
        
        private function deauthenticate() {
            $path = 'api/v1/logout';
            $user = array(
                'user' => RC_USR,
                'password' => RC_PASS
            );

            $opts = $this->requestOpts($path, 'POST', json_encode($user), array("Content-Type: application/json"));

            $curl = curl_init();
            curl_setopt_array($curl, $opts);
            $response = curl_exec($curl);
            curl_close($curl);
        }

        private function createUser($userid, $username, $email, $password) {
            
            if (!$this->token)
                $this->authenticate();
                
            $path = 'api/v1/users.create';
            $newUser = array(
                'name' => $userid,
                'email' => $email,
                'password' => $password,
                'username' => $username,
                'joinDefaultChannels' => true,
                'requirePasswordChange' => false,
                'sendWelcomeEmail' => false,
                'verified' => true,
            );

            $curl = curl_init();
            curl_setopt_array($curl, $this->requestOpts($path, 'POST', json_encode($newUser), $this->getAuthenticationHeaders()));
            $response = curl_exec($curl);
            
            if($response === false) {
                error_log("Error: Calling Add User endpoint - $userid, $username, $email - " . curl_error($curl));
            } else{
                $result = json_decode($response);
                
                if ($result->success || $result->success == 'true') {
                    $this->cnt++;
                } else {
                    error_log("Error: Adding User - $userid, $username, $email - $response");
                }
            }
            curl_close($curl);
            
        }
        
        private function updateUser($username, $fieldname, $newvalue) {
            if (!$this->token)
                $this->authenticate();
                
            $userid = $this->getUserId($username);
            
            echo $userid . "-" . $username . "\n";
            if ($userid) {
                $path = 'api/v1/users.update';
                $updateUser = array(
                    'userId' => $userid,
                    'data' => array($fieldname => $newvalue,
                        'active' => true,
                        'sendWelcomeEmail' => false, 
                        'verified' => true)
                );
    
                $curl = curl_init();
                curl_setopt_array($curl, $this->requestOpts($path, 'POST', json_encode($updateUser), $this->getAuthenticationHeaders()));
                $response = curl_exec($curl);
                
                if($response === false) {
                    error_log("Error: Calling Update User endpoint - $userid, $username - " . curl_error($curl));
                } else{
                    $result = json_decode($response);
                    
                    if ($result->success || $result->success == 'true') {
                        $this->cnt++;
                    } else {
                        error_log("Error: Updating User - $userid, $username - $result->error");
                    }
                }
                curl_close($curl);
            }
        }
        
        private function getUserId($username) {
            $path = "api/v1/users.info?username=$username";
            
            $curl = curl_init();
            curl_setopt_array($curl, $this->requestOpts($path, 'GET', null, $this->getAuthenticationHeaders()));
            $response = curl_exec($curl);
            curl_close($curl);
            
            $result = json_decode($response, true);
            
            if ($result['success'] == 'true') {
                return $result['user']['_id'];
            }
            
            return null;
        }
        
        private function changeActiveStatus($username, $status) {
             if (!$this->token)
                $this->authenticate();
                
            $userid = $this->getUserId($username);

            if ($userid) {
                $path = 'api/v1/users.update';
                $updateUser = array(
                    'userId' => $userid,
                    'data' => array("active" => $status)
                );
    
                $curl = curl_init();
                curl_setopt_array($curl, $this->requestOpts($path, 'POST', json_encode($updateUser), $this->getAuthenticationHeaders()));
                $response = curl_exec($curl);
                curl_close($curl);
            }
        }

        private function getAuthenticationHeaders() {
            return  array(
                "X-User-Id: $this->userId",
                "X-Auth-Token: $this->token",
                "Content-Type: application/json"
            );
        }

        private function requestOpts($path, $method, $bodyArgs, $headers) {
            return array(
                CURLOPT_URL => $this->baseURL . $path,
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_ENCODING => "",
                CURLOPT_MAXREDIRS => 10,
                CURLOPT_TIMEOUT => 0,
                CURLOPT_FOLLOWLOCATION => true,
                CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                CURLOPT_CUSTOMREQUEST => $method,
                CURLOPT_POSTFIELDS => $bodyArgs,
                CURLOPT_HTTPHEADER => $headers,
            );
        }
        
        private function setCredentials() {
            if (file_exists ('auth.cnf')) {
                $file = fopen('auth.cnf', 'r');
                $cnf = fread($file, filesize('auth.cnf'));
                fclose($file);
                
                $result = json_decode($cnf);
                $this->token = $result->token;
                $this->userId = $result->userid;
                
                if(date('Y-m-d') > $result->exp) {
                    $this->deauthenticate();
                    $this->token = null;
                    $this->userId = null;
                }
            }
        }
        
        private function saveCredentials() {
            $file = fopen('auth.cnf', 'w');
            $exp = date('Y-m-d', strtotime( $d . " +1 month"));
            fwrite($file, "{\"token\": \"$this->token\", \"userid\": \"$this->userId\", \"exp\": \"$exp\" }");
            fclose($file);
        }
    }
?>